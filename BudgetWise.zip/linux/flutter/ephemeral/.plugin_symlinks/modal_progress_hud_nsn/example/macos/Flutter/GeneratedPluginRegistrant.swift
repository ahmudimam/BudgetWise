//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import modal_progress_hud_nsn

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  ModalProgressHudNsnPlugin.register(with: registry.registrar(forPlugin: "ModalProgressHudNsnPlugin"))
}
