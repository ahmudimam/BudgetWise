package boi.walle.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
